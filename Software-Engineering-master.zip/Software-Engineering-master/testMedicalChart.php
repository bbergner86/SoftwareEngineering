<?php
$now = date('m/d/Y');
echo "<html>
	  <body>
	  		<h1 style=\"color: red\">
	  				 Patient Chart
	  		</h1>
	  		<hr />
	  		<p id=\"main-paragraph\">
	  				Account Number: 12345
	  				Admit Date: $now
	  				Primary Care Physician: Dr Rockso
	  				Room #: 2112
	  				Patient Name: Christian Wilson
	  				SSN: 123-45-6789
	  				Adresss: 5150 Rush St, San Antonio, TX 78249
	  				Phone #: (987)123-4567
	  				DOB: 09/19/1995
	  				Sex: M
	  				Race: White
	  				Height: 5'10\"
	  				Weight: 275 lbs
	  				Family History: cancer, pneumonia, obesity, leprosy, bubonic plague
	  				Allergies: None
	  				Patient Employer:
	  				Reason For Visit:
	  				Insurance:
	  				Current Diagnosis: strep throat

	  		</p>
	   </body>
	  </html>";
?>